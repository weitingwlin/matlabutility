

function myplot(X,Y,type,color)
if (nargin < 4), color = 3; end;
if (nargin < 3), type = ('S'); end;
script_mycolorplate
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if type=='S'
    plot(X,Y,'o','color',mycolor(color,:),'Markerfacecolor',mycolor(color,:))
     set(gca,'FontSize',14,'linewidth',2)
end

if type=='L'
    plot(X,Y,'linewidth',2,'color',mycolor(color,:))
     set(gca,'FontSize',14,'linewidth',2)
end
