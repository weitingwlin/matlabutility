% Create a matrix called   [mycolor], each row is a 3-number vector code for a color.
%  e.g.
%   mycolor(3,:)=
% 
% And some color plate from paintings
% Row 14~20 :From the lake
% Row 21~27: Caf? Tarrace at Night
% Row 28~33: Feng Tzi-kai

%% 
mycolor(1,:) = ([0 0 0]);
mycolor(2,:) = ([0.8 0.2 0.2]);
mycolor(3,:) = ([0.0 0.2 0.6]);
mycolor(4,:) = ([0.1 0.5 0.1]);
mycolor(5,:) = ([0.8 0.7 0.1]);
mycolor(6,:) = ([0.4 0.1 0.8]);
mycolor(7,:) = ([0.4 0.4 0.4]);
mycolor(8,:) = ([0.2 0.7 0.8]);
mycolor(9,:) = ([0.6 0.2 0.2]);
mycolor(10,:) = ([0.8 0.1 0.8]);
mycolor(11,:) = ([0.0 0.4 0.6]);
mycolor(12,:) = ([0.5 0.8 0.0]);
mycolor(13,:) = ([0.9 0.4 0.1]);
% 
mycolor(14,:) =([0.0745    0.2078    0.3686]);
mycolor(15,:) =([0.1765    0.6275    0.6431]);
mycolor(16,:) =([0.3725    0.0588    0.0784]);
mycolor(17,:) =([0.4039    0.4235    0.4902]);
mycolor(18,:) =([0.1373    0.4902    0.3255]);
mycolor(19,:) =([0.7765    0.4510    0.0196]);
mycolor(20,:) =([0.9725    0.9529    0.8431]);
%
mycolor(21,:) =([0.0588    0.2941    0.6353]);
mycolor(22,:) =([0.0784    0.2588    0.0745]);
mycolor(23,:) =([0.6588    0.3529         0]);
mycolor(24,:) =([0.4196    0.5098    0.4314]);
mycolor(25,:) =([0.4980    0.5412    0.0902]);
mycolor(26,:) =([0.9216    0.7961    0.2745]);
mycolor(27,:) =([0.9608    0.9569    0.8314]);
%
mycolor(28,:) =([0.5333    0.7216    0.8471]);
mycolor(29,:) =([0.9373    0.8706    0.7216]);
mycolor(30,:) =([0.9725    0.1804    0.0863]);
mycolor(31,:) =([0.2706    0.3020    0.3569]);
mycolor(32,:) =([0.0980    0.4039    0.2667]);
mycolor(33,:) =([0.9922    0.4392    0.2353]);
%%
%  [n,p] = size(mycolor)

% for c = 0:n-1
%  plot([0 cos(0.15*c)],[0 sin(0.15*c)],'Linewidth',3,'color',mycolor(c+1,:));hold on
%  text(cos(0.15*c)*1.05,sin(0.15*c)*1.05,num2str(c+1))
% end
% axis([-1.1 1.1 -1.1 1.1])
% axis off
%%
mygrays(1,:)= ([0 0 0]);
mygrays(2,:)= ([0.3 0.3 0.3]);
mygrays(3,:)= ([0.45 0.45 0.45]);
mygrays(4,:)= ([0.6 0.6 0.6]);
mygrays(5,:)= ([0.8 0.8 0.8]);
mygrays(6,:)= ([0.9 0.9 0.9]);
%%
% figure
%  [n,p] = size(mygrays)

% for c = 0:n-1
%  plot([0 cos(0.15*c)],[0 sin(0.15*c)],'Linewidth',3,'color',mygrays(c+1,:));hold on
%  text(cos(0.15*c)*1.05,sin(0.15*c)*1.05,num2str(c+1))
% end
% axis([-1.1 1.1 -1.1 1.1])
 %axis off
%%
save my_colorplates mycolor mygrays